This a CRUD(Create Read and Write Project) in PHP by Tauleshwar Thakur(me)

Requirements to run the project
1. PHP server
2. Mysql Databse should be imported fro SQL DATABASE FILE TO BE IMPORTED IN DATABASE folder inside this project 
and configured properly in functions/config/db.php

3. ROOT_URL is set to 127.1.1.0/crudphp/ in functions/config/conf.php
4. For ui bootstrap is used


Credentials
To use this project you have to be one of the admin which you can become by signing up but you have to approve yourself from database by changing approve col of admin from 0 to 1

Default Admin
username : Tauleshwar
pass : open


