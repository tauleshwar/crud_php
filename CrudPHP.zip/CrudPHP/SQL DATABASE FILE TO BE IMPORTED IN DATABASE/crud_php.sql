-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 30, 2021 at 01:30 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud_php`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `approved`) VALUES
(4, 'Tauleshwar', 'me@tauleshwarthakur.com.np', '$argon2i$v=19$m=65536,t=4,p=1$SHJEQzZWL056WmVlckFtWA$BhtpASX+DVj+fP2Zt0JVQ2OlpxE4kQL60/v3g4dO4HA', 1);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `imageName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `password`, `imageName`) VALUES
(36, 'Warren', 'war@jj.kool', 'open', 'Warren.jpg'),
(37, 'Toe', 'toe@jj.kool', 'open', 'Toe.jpg'),
(38, 'swapnil', 'swapnil@jj.kool', 'open', 'swapnil.jpg'),
(39, ' Ruiza ', ' rui@jj.kool', ' open', 'Rui.jpg'),
(40, 'Raju', 'raju@jj.kool', 'open', 'Raju.jpg'),
(41, 'Luv', 'luv@jj.kool', 'openll', 'Luv.jpg'),
(42, 'Jay', 'jay@jj.kool', 'open', 'Jay.jpg'),
(43, 'Rex', 'rex@jj.kool', 'open', 'Rex.jpg'),
(44, 'Mia Jaffar', 'mia@jj.kool', 'open', 'MiaJaffar.jpg'),
(46, 'Tauleshwar Thakur', 'Tauleshwar@jj.kool', 'open', 'TauleshwarThakur.jpg'),
(47, 'Dani', 'dani@jj.kool', 'open', 'Dani.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
