<?php 
include 'functions/config/db.php';
include 'functions/config/user_session.php';

?>
<?php include_once'inc/header.php'?>
    <div class="container-sm">
        
        <?php 
        if (!isset($userName)){  
            include "signin_signup_form.php";
            }
            else{
                
                ?>
                <div class="loggedin">
                    <h1><?php echo $userData['name'];?></h1>
                    <a href="functions/logout.php">
                    <button type="button" class="btn btn-danger" href="functions/logout.php">Logout</button>    
                    </a>           
                </div>
                <br>
                <h1 class="text-center">CUSTOMERS</h1>
                <h3 class=" text-center ">Add Customers</h3>
        <?php include_once'show_customer.php'?>
        <?php }  ?>
    </div>
<?php include_once'inc/footer.php'?>