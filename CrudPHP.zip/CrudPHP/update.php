<?php
include 'inc/header.php';
require_once('functions/config/db.php');
if (isset($_GET['id'])) {

    $userId = $_GET['id'];

    $query = "SELECT * FROM customers WHERE id= $userId";
    $result1 = mysqli_query($conn, $query);
    if ($result1) {
        $userData = mysqli_fetch_assoc($result1);

        $_SESSION['userId'] = $userId;
        $_SESSION['userName'] = $userData['name'];
    }
}

?>

<div class="container">



    <h1 class="text-center">Update Customer</h1>

    <div class="text-center bg-black ">

        <div class="forms  col mx-auto  col-md-4 col-sm-8 " id="signUpForm">
            <!-- SignUp Form -->
            <form class="form-signup " action="functions/update_customer.php?id=<?php echo $userId;?>" method="post" enctype="multipart/form-data">

                <input type="username" name="name" id="inputUsername" class="form-control" placeholder="<?php echo$userData['name']; ?>">
                <input type="email" name="email" id="inputEmail" class="form-control" placeholder="<?php echo$userData['email']; ?>" >
                <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password" >
                <label for="image">Update Image</label>
                <img style="height: 100px; width:100px" src="uploads/profile/<?php echo$userData['imageName']; ?>" alt="">

                <input type="file" name="image" accept="image/x-png" class="form-control" id="inputGroupFile04" >
        </div>
        <br>
        <button class="btn btn-lg btn-primary btn-block" type="submit" name="submit">Update</button>
        </form>
    </div>

    <br>

</div>




<?php include_once 'inc/footer.php' ?>