<?php 
include_once 'config/db.php';
// include_once 'config/user_session.php';


if(!empty($_GET['id'])){
    $userId = $_GET['id'];
    
    $deleteQuery = "DELETE FROM `customers` WHERE `customers`.`id` = $userId";
    if(mysqli_query($conn,$deleteQuery)){
        header("Location: ../index.php?msg=Deleted Successfully");

    }


}


?>