<?php
include_once 'config/conf.php0';
session_start();
unset($_SESSION['name']);
session_destroy();
header("Location: ../index.php");
?>