<?php
require_once('config/secret_key.php');
include 'config/db.php';
$targetfolder = "../uploads/profile/";
$id;
if (isset($_GET['id'])) {
    $id = $_GET['id'];
}


if (isset($id)) {
 
    if (isset($_POST)) {

        if (!empty($_POST['name'])) {
            $value =$_POST['name'];
            $query = "UPDATE `customers` SET `name` = ' $value' WHERE `customers`.`id` = $id";
            if (mysqli_query($conn, $query)) {

            } 

        }

        if (!empty($_POST['email'])) {
            $value =$_POST['email'];
            $query = "UPDATE `customers` SET `email` = ' $value' WHERE `customers`.`id` = $id";
            if (mysqli_query($conn, $query)) {
                
            } 
        }

        if (!empty($_POST['password'])) {
            $value =$_POST['password'];
            $query = "UPDATE `customers` SET `password` = ' $value' WHERE `customers`.`id` = $id";
            if (mysqli_query($conn, $query)) {
                
            } 
        }

        if (!empty($_FILES['image'])) {
            $imageName;
            $query = "SELECT * FROM customers WHERE id=$id";
            $result1 = mysqli_query($conn, $query);
            if($result1){
                $userData = mysqli_fetch_assoc($result1);
                $userID = $userData['id'];
                $imageName = $userData['imageName'];
            }else header("Location: ../index.php?msg=Sql not ok".$imageName);

            move_uploaded_file($_FILES['image']['tmp_name'], $targetfolder.$imageName);
                
            header("Location: ../index.php?msg=Update Sucessfull");

        }
        
    }
}
