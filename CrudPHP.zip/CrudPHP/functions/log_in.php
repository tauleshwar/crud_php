<?php
session_start();        
require_once ('config/secret_key.php');
require_once ('config/db.php');

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $username = $_POST["username"];
    $password = $_POST["password"];

    
    $validPassword = $password.secSalt;
    

    
  

    $query="SELECT * FROM `admin` WHERE `name`='$username'";
    $result1=mysqli_query($conn , $query);
    $error= mysqli_error($conn);
    $userData = mysqli_fetch_assoc($result1);


    
    $hashedPwd = $userData['password'];
    $ifLegitUser  = password_verify($validPassword, $hashedPwd );
    
    if(mysqli_num_rows($result1)>0){
        

        if($ifLegitUser==true){
            $isApproved = $userData['approved'];
        
        
            if($isApproved==1){
            // if works goes to display customers on index page
                $_SESSION['name']=$username;
                include_once './functions/user_session.php';
        
                header("location: ../index.php");
            }
            else{
                header("location: ../index.php?msg=You are not approved");
            }
        }
        else{
            
            header("location: ../index.php?msg=Incorrect password.");
        }
        

    }else{
      
        header("location: ../index.php?msg=You dont have a accout please signup");
    }
    

}
else{
    header("location: ../index.php");
}