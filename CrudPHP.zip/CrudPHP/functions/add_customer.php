<?php
require_once('config/db.php');
require_once('config/secret_key.php');
$targetfolder = "../uploads/profile/";


if(!empty($_POST['name']) ){
    $fullName = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Get name of images
    $image_name = $_FILES['image']['name'];
    $temp = explode(".", $image_name);
    $tempUserName = str_replace(' ', '', $fullName);
    $new_image_name = $tempUserName. '.' . end($temp);
    
    
$queryAdd = "INSERT INTO `customers` ( `name`, `email`, `password`, `imageName`) VALUES ( '$fullName', '$email', '$password', '$new_image_name')";

if(mysqli_query($conn , $queryAdd)){
    header("location: ../index.php?msg=Added Sucessfully.");
    
    if (move_uploaded_file($_FILES['image']['tmp_name'], $targetfolder.$new_image_name)) {
        header("Location: ../index.php?msg=Added Sucessfully");
    }
}
else{
    $err = mysqli_error($conn);
    header("location: ../index.php?msg=Failed on db level".$err);

}

}


   
?>
