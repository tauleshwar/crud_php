<?php
define("secSalt", "nothackable");
?>