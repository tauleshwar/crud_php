<?php
session_start();

if (isset($_SESSION['name'])) {
    require_once('db.php');
    $userName = $_SESSION['name'];

    $query = "SELECT * FROM admin WHERE name='$userName'";
    $result1 = mysqli_query($conn, $query);
    if($result1){
        $userData = mysqli_fetch_assoc($result1);
        $userID = $userData['id'];
    
        $_SESSION['userId'] = $userID;
        $_SESSION['userName'] = $userData['name'];
    }

    $queryCutomers = "SELECT * FROM `customers` LIMIT 0,10 ";
    
    $resultCustomers = mysqli_query($conn, $queryCutomers);
    if($resultCustomers){
        $Customers= mysqli_fetch_all($resultCustomers, MYSQLI_ASSOC);
    }else echo mysqli_error($conn);

      

    mysqli_close($conn);
}
