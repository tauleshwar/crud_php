<?php
define('ROOT_URL','http://127.0.0.1/crudphp');

?>