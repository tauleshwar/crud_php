<?php 
require_once ('config/db.php');
require_once ('config/secret_key.php');


if(!empty($_POST['username']) ){
    $fullName = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password2 = $_POST['password2'];
    $approved= 0;

    if($password==$password2){
        $password = $password;
    
    $validPassword = $password.secSalt;
    $hashedPwd = password_hash($validPassword, PASSWORD_ARGON2I);


         
    $querySignup = "INSERT INTO `admin` (`id`, `name`, `email`, `password`, `approved`) VALUES (NULL, '$fullName', '$email', '$hashedPwd', '0')";

    if(!empty($validPassword)){
   
    if(mysqli_query($conn , $querySignup)){
     
        header("location: ../index.php?msg=Signup Sucessful Wait for approval!.");
    }
    else{

        header("location: ../index.php?msg=Failed on db level");

    }
}
}else{
    header("location: ../index.php?msg=Password are not same'");

}

    


}