// const signUpButtonT = document.getElementById('signUpT');
// const signInButtonT = document.getElementById('signInT');

const signUpForm = document.getElementById('signUpForm');
const signInForm = document.getElementById('signInForm');

function showSignUp(){
    signInForm.style.display='none';
    signUpForm.style.display='block';
	
}

function showSignIn(){
    signInForm.style.display='block';
	signUpForm.style.display='none';
    
    
}