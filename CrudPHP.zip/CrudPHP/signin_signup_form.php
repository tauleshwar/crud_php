<?php
?>
<div class="text-center alert-warning"> <?php 
    if(isset($_GET["msg"])){ 
    echo strval($_GET["msg"]) . '!';
    }
    ?>
</div>
<link rel="stylesheet" href="css/forms.css">



<div class="text-center">
        <h2>Please Login with your Admin account.
        </h2>

        <!-- <button onClick="showSignUp()" >Sign Up</button> -->

        <button onClick="showSignUp()">SignUp</button>
        <button onClick="showSignIn()">SignIn</button>


</div>
<br>
<div class="text-center  row container-fluid">

        <div class="forms  hide col mx-auto  col-md-4 col-sm-8 " id="signUpForm">
              <!-- SignUp Form -->
            <form class="form-signup " action="functions/sign_up.php" method="post">
                <br>
                <input type="username" name="username" id="inputUsername" class="form-control" placeholder="Full Name"
                    required autofocus>
                <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email" required>
                <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password"
                    required>
                <input type="password" name="password2" id="inputPassword2" class="form-control"
                    placeholder="Confirm Password" required>
                <br>
                <button class="btn btn-lg btn-primary btn-block" type="submit">Sign Up</button>

            </form>
        </div>





        <div class="forms col mx-auto  col-md-4 col-sm-8 " id="signInForm">
            <!-- SignIn Form -->
            <form class="form-signin " action="functions/log_in.php" method="post">
                <br>
                <input type="username" name="username" id="inputUsername" class="form-control"
                    placeholder="Username" required autofocus>
                <br>
                <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password"
                    required>
                <br>
                <button class="btn btn-lg btn-primary btn-block" type="submit">Sign In</button>

            </form>
        </div>



    </div>
</div>


<script src="js/forms.js"></script>
