<?php include_once 'functions/config/user_session.php' ?>

<link rel="stylesheet" href="css/forms.css">
<link rel="stylesheet" href="css/style.css">
<!-- <link rel="stylesheet" href="css/style.css"> -->

<div class="text-center alert-warning"> <?php
                                        if (isset($_GET["msg"])) {
                                          echo "<h2>" . strval($_GET["msg"]) . "</h2>";
                                        }
                                        ?>



</div>



<div class="text-center bg-black ">

  <div class="forms  col mx-auto  col-md-4 col-sm-8 " id="signUpForm">
    <!-- SignUp Form -->
    <form class="form-signup " action="functions/add_customer.php" method="post" enctype="multipart/form-data">

      <input type="username" name="name" id="inputUsername" class="form-control" placeholder="Full Name" required autofocus>
      <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email" required>
      <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password" required>
      <input type="file" name="image" accept="image/*" class="form-control" id="inputGroupFile04" aria-describedby="inputGroupFileAddon04" aria-label="Upload" required autofocus required>
  </div>
  <br>
  <button class="btn btn-lg btn-primary btn-block" type="submit" name="submit">Add</button>
  </form>
</div>














<br>
  <div class="customers-list container row">

    
    <?php

    foreach ($Customers as $Customer) : ?>

      <?php
      $username = $Customer['name'];

      ?>
      <div class="card  mb-4 mx-2 col-md-3 col col-sm-12 col-12">
        <div class="row card ">
          <div class=" ">
            <img src="uploads/profile/<?php echo $Customer['imageName'] ?>" class="img-fluid rounded-start" alt="...">
          </div>
  
            <div class="card-body">
              <h3 class=""><?php echo $username ?></h3>
              <p class="card-text" style="color:black"><?php echo $Customer['email']; ?></p>

              <a href="update.php?id=<?php echo $Customer['id']; ?>">
                <button type="button" class="btn btn-secondary" onclick="updateUser">Update</button>
              </a>

              <a href="functions/delete.php?id=<?php echo $Customer['id']; ?>">
                <button type="button" class="btn btn-danger">Delete</button>
              </a></td>

    
          </div>
        </div>

      </div>
    <?php endforeach; ?>
  </div>

</div>